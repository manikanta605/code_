import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NERService {

  constructor(private http:HttpClient) { }


  getLabel(){
    return this.http.get('http://localhost:1300/get_label')
  }

  addLabel(label:any){
    return this.http.post('http://localhost:1300/add_label',label)
  }

  // http://localhost:1300/image_data_text   
  getImageData(){
    return this.http.get('http://localhost:1300/image_data_text')
  }
  getImageData_id(id:any){
    return this.http.get(`http://localhost:1300/image_data_text/${id}`)
  }

  completJsonData(data:any){
    return this.http.post('http://localhost:1300/add_model_json',data)
  }
  json_data_str(id:any){
    return this.http.get(`http://localhost:1300/json_data_text/${id}`)
  }
}
