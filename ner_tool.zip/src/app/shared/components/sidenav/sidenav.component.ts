import { Component, ElementRef, ViewChild } from '@angular/core';

@Component({
    selector: 'app-sidenav',
    templateUrl: './sidenav.component.html',
    styleUrls: ['./sidenav.component.scss'],
    standalone: false
})
export class SidenavComponent {
  @ViewChild('sidebar') sidebar: ElementRef | undefined;

  menuItems = [
    { path: '/dashboard', icon: 'fa-solid fa-chart-line', label: 'Dashboard' },
    { path: '/dataset', icon: 'fa-regular fa-user', label: 'Dataset' },
    { path: '/labels', icon: 'fa-regular fa-keyboard', label: 'Labels' },
    { path: '/chatbot', icon: 'fa-brands fa-react', label: 'Chatbot' },
    { path: '/settings', icon: 'fa-regular fa-message', label: 'Settings' },
    // { path: '/help', icon: 'fa-solid fa-info', label: 'Help' },
    { path: '/review', icon: 'fa-solid fa-info', label: 'Review' }
  ];

  // Function to toggle sidebar open class
  toggleSidebar(): void {
    if (this.sidebar) {
      this.sidebar.nativeElement.classList.toggle("open");
    }
  }

  // Function to change the menu button icon
  menuBtnChange(target: EventTarget | null): void {
    if (target instanceof HTMLElement && this.sidebar) {
      if (this.sidebar.nativeElement.classList.contains("open")) {
        target.classList.replace("fa-bars", "fa-solid fa-xmark");
      } else {
        target.classList.replace("fa-solid fa-bars", "fa-bars");
      }
    }
  }
}
