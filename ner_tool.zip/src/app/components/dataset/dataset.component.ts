import { Component, ViewChild, ElementRef, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NERService } from '../../shared/ner.service';

interface User {
  id: number;
  name: string;
  status: string;
  text: string;
  lastActive: Date;
  commentCount: number;
  selected: boolean;
}

@Component({
  selector: 'app-dataset',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './dataset.component.html',
  styleUrl: './dataset.component.scss'
})
export class DatasetComponent implements OnInit {
  // Table data
  allUsers: any = [];
  displayedUsers: any= [];
  filteredUsers: User[] = [];
  
  // Pagination
  currentPage: number = 1;
  itemsPerPage: number = 10;
  totalPages: number = 1;
  pages: number[] = [];
  
  // Other properties
  totalUsers: number = 0;
  searchTerm: string = '';
  selectAll: boolean = false;
  sortColumn: string = 'lastActive';
  sortDirection: 'asc' | 'desc' = 'desc';

  isModalOpen: boolean = false;
  hasSelectedFiles: boolean = false;
  @ViewChild('fileInput') fileInput!: ElementRef;

  constructor(private nerservice:NERService) { }

  ngOnInit(): void {
    this.loadDummyData();
    this.applyFilter();
  }
 Math = Math;
  loadDummyData(): void {
    const statuses = ['Finished', 'In Progress', 'New'];

    this.nerservice.getImageData().subscribe((data:any)=>{
      console.log(data);

      data.map((res:any, index:any) => {
        this.allUsers.push({
          id: index,
          sno:res.id,
          status: "In Progress",
          text: res.text,
         
        });
      })
      console.log("",this.allUsers);
      this.filteredUsers = this.allUsers;
      this.updatePagination();
      this.updateDisplayedUsers();
      this.totalUsers = this.allUsers.length;
    })
      // this.allUsers = data;
      
    
    // Generate dummy data for demo
    // const sampleTexts = [
    //   "He'd never liked walking under that tree, not for as long as he could remember. And now the kid would be up there, like every afternoon this week, nestling in the twisting branches as if that were the...",
    //   "The road stretched out ahead, seemingly endless. Sarah had been driving for hours, the landscape gradually changing from dense forests to open plains. She checked her fuel gauge and frowned...",
    //   "The conference room fell silent as the CEO entered. Everyone knew what was coming, but nobody wanted to be the first to acknowledge it. The quarterly report had been the worst in company history...",
    //   "The recipe called for exactly three teaspoons of vanilla extract, but Maria always added a little extra. It was her grandmother's secret, passed down through generations. The cookies wouldn't taste right otherwise...",
    //   "The alarm clock beeped incessantly, but Jake couldn't bring himself to reach over and turn it off. Another day, another dollar, as they say. But lately, he'd been wondering if there was more to life than this endless cycle..."
    // ];

   

    // // Generate 44 users
    // for (let i = 1; i <= 44; i++) {
    //   const randomDate = new Date();
    //   randomDate.setDate(randomDate.getDate() - Math.floor(Math.random() * 30));
      
    //   this.allUsers.push({
    //     id: i,
    //     name: `User ${i}`,
    //     status: statuses[Math.floor(Math.random() * statuses.length)],
    //     text: sampleTexts[Math.floor(Math.random() * sampleTexts.length)],
    //     lastActive: randomDate,
    //     commentCount: Math.floor(Math.random() * 5),
    //     selected: false
    //   });
    // }

    // // Set Florence Shaw as the first user
    // this.allUsers[0] = {
    //   id: 1,
    //   name: 'Florence Shaw',
    //   status: 'Finished',
    //   text: "He'd never liked walking under that tree, not for as long as he could remember. And now the kid would be up there, like every afternoon this week, nestling in the twisting branches as if that were the...",
    //   lastActive: new Date('2024-03-04'),
    //   commentCount: 1,
    //   selected: false
    // };
    
    
  }

  applyFilter(): void {
    // Apply search filter
    if (this.searchTerm) {
      const term = this.searchTerm.toLowerCase();
      this.filteredUsers = this.allUsers.filter((user:any) => 
        user.name.toLowerCase().includes(term) || 
        user.text.toLowerCase().includes(term) ||
        user.status.toLowerCase().includes(term)
      );
    } else {
      this.filteredUsers = [...this.allUsers];
    }
    
    // Apply sorting
    this.sortData();
    
    // Update pagination
    this.updatePagination();
    
    // Update displayed users
    this.updateDisplayedUsers();
  }

  sortData(): void {
    this.filteredUsers.sort((a, b) => {
      const aValue = a[this.sortColumn as keyof User];
      const bValue = b[this.sortColumn as keyof User];
      
      if (aValue < bValue) {
        return this.sortDirection === 'asc' ? -1 : 1;
      }
      if (aValue > bValue) {
        return this.sortDirection === 'asc' ? 1 : -1;
      }
      return 0;
    });
  }

  updatePagination(): void {
    this.totalPages = Math.ceil(this.filteredUsers.length / this.itemsPerPage);
    
    // Ensure current page is valid
    if (this.currentPage > this.totalPages) {
      this.currentPage = this.totalPages || 1;
    }
    
    // Generate page numbers array
    this.pages = Array.from({length: this.totalPages}, (_, i) => i + 1);
  }

  updateDisplayedUsers(): void {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    this.displayedUsers = this.filteredUsers.slice(startIndex, endIndex);
  }

  changePage(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
      this.updateDisplayedUsers();
    }
  }

  sort(column: string): void {
    if (this.sortColumn === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumn = column;
      this.sortDirection = 'asc';
    }
    
    this.applyFilter();
  }

  toggleSelectAll(): void {
    this.displayedUsers.forEach((user:any) => {
      user.selected = this.selectAll;
    });
  }

  openFilters(): void {
    // Implement filter modal/dropdown logic
    console.log('Open filters');
  }

  openAddUserModal(): void {
    this.isModalOpen = true;
  }

  closeModal(): void {
    this.isModalOpen = false;
  }

  onDragOver(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
  }

  onDragLeave(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
  }

  onDrop(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    const files = event.dataTransfer?.files;
    if (files) {
      this.handleFiles(files);
    }
  }

  triggerFileInput(): void {
    this.fileInput.nativeElement.click();
  }

  onFileSelected(event: Event): void {
    const element = event.target as HTMLInputElement;
    const files = element.files;
    if (files) {
      this.handleFiles(files);
    }
  }

  handleFiles(files: FileList): void {
    // Handle the selected files here
    this.hasSelectedFiles = files.length > 0;
  }

  uploadFiles(): void {
    // Implement file upload logic here
    console.log('Uploading files...');
  }

  editUser(user: User): void {
    // Implement edit user logic
    console.log('Edit user', user);
  }

  deleteUser(user: User): void {
    // Implement delete user logic
    console.log('Delete user', user);
    
    // For demo purposes, remove from arrays
    this.allUsers = this.allUsers.filter((u:any) => u.id !== user.id);
    this.filteredUsers = this.filteredUsers.filter(u => u.id !== user.id);
    this.totalUsers = this.allUsers.length;
    
    this.updatePagination();
    this.updateDisplayedUsers();
  }

  onSearchInput(event: Event): void {
    const target = event.target as HTMLInputElement;
    this.searchTerm = target.value;
    this.applyFilter();
  }
}
