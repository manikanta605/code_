import { Component, ElementRef, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { NERService } from '../../shared/ner.service';
import { ActivatedRoute, Router } from '@angular/router';
interface TabItem {
  title: string;
  description: string;
  image: string;
}
@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrl: './review.component.scss',
  standalone: false

})
export class ReviewComponent {
  labeldata:any;
  jsonFormat:any
  textData:any;
  formattedOutput:any
  lengthdata:any
  imagesData:any;
  currentPage:any;
  folder_name:any
  file_name:any;
  completeButton:boolean = false
@Input() label!: string;
  @Output() action = new EventEmitter<void>();
  labelToAdd: string = '';
  @ViewChild('selectedText') selectedText!: ElementRef;
  batchCounts: { [key: string]: number } = {};
  labeleObjectvalue:any = [];
  keyValue:any = []
  text_id:any



constructor(private nerService: NERService, private activateRouter:ActivatedRoute, private router:Router
) {
  this.activateRouter.params.subscribe((value:any)=>{  
    console.log("params",value);
      this.showData(value.id)
      this.loadDummyData()
      
  })

 }
ngOnInit() {
this.getLabels()
}


showData(value:any){

  this.nerService.getImageData_id(value).subscribe((data:any)=>{ 
    this.text_id = value
    console.log("data",data);   
   this.textData = data[0].text
   this.file_name = data[0].file_name
   this.folder_name = data[0].folder_name
   
  })
  this.json_data_text(value)
}
  getLabels(){
    this.nerService.getLabel().subscribe((data:any)=>{
        console.log("data",data);
        this.labeldata = data
    })
}

onAction() {
  this.action.emit();
}

addLabel(textArea: HTMLTextAreaElement) {
  const start = textArea.selectionStart;
  const end = textArea.selectionEnd;
  if (start !== end) {
    const selectedText = textArea.value.substring(start, end);
    const labeledText = `<${this.labelToAdd}>${selectedText}</${this.labelToAdd}>`;
    textArea.value = textArea.value.substring(0, start) + labeledText + textArea.value.substring(end);
  }
}

storeSelectedText(event: MouseEvent) {
  const textarea = event.target as HTMLTextAreaElement;
  const selectedText = textarea.value.substring(textarea.selectionStart, textarea.selectionEnd);
  this.selectedText.nativeElement.value = selectedText;
}

addPredefinedLabel(label: string, selectedText: string) {


  this.keyValue.push({label:label,selectedText:selectedText})

  const startIndex = this.textData.indexOf(selectedText);

  const endIndex = startIndex + selectedText.length;

  this.formattedOutput = this.convertToPatternFormat(this.textData, this.keyValue);

  // Create labeled object
  const labeledObject = {
    start: startIndex,
    end: endIndex,
    label: label
  };

  // Initialize JSON format object
  const jsonFormat: { text: string; spans: { start: number; end: number; label: string }[] } = {
    text: this.textData,
    spans: this.labeleObjectvalue
  };

  this.jsonFormat = jsonFormat;

  this.labeleObjectvalue.push(labeledObject);

  console.log("jsonFormat Object:", labeledObject);
  console.log("jsonFormat",this.jsonFormat)
  console.log("jsonFormat",this.keyValue)
  console.log("formattedOutput",this.formattedOutput);


  // Ensure batchCounts is defined
  if (!this.batchCounts) {
    this.batchCounts = {};
  }

  // Increment batch count for the label
  this.batchCounts[label] = (this.batchCounts[label] || 0) + 1;

}

 convertToPatternFormat(textData:any, annotations:any) {
  let extractedTexts = annotations.map((item:any) => item.selectedText);
  let labels = annotations.map((item:any) => item.label);

  return `("${textData}", ${JSON.stringify(extractedTexts)}, ${JSON.stringify(labels)})`;
}


deleteRow(item:any){

  console.log("deleteRow",item)

  this.keyValue = this.keyValue.filter((i:any) => i !== item);
  console.log("deleteRow",this.keyValue)

  this.labeleObjectvalue = this.removeMatchingObject(this.textData, this.labeleObjectvalue, item.selectedText, item.label);

  const jsonFormat: { text: string; spans: { start: number; end: number; label: string }[] } = {
    text: this.textData,
    spans: this.labeleObjectvalue
  };
  this.jsonFormat = jsonFormat;

  console.log("jsonFormat",this.jsonFormat)

  this.formattedOutput = this.convertToPatternFormat(this.textData, this.keyValue);
  console.log("formattedOutput",this.formattedOutput)
  // this.labeleObjectvalue = this.labeleObjectvalue.filter((i:any) => i !== item);
  // console.log("deleteRow",this.labeleObjectvalue)
  // this.keyValue = this.labeleObjectvalue
}


removeMatchingObject(textData:any, annotations:any, removeText:any, removeLabel:any) {
  const startIndex = textData.indexOf(removeText);
  
  if (startIndex !== -1) {
      const endIndex = startIndex + removeText.length;

      // Filter out the object that matches both text and label
      const filteredAnnotations = annotations.filter((item:any) => 
          !(item.start === startIndex && item.end === endIndex && item.label === removeLabel)
      );

      return filteredAnnotations;
  }
  
  return annotations; // Return original if text not found
}

changePage(value:any,page:any){
  console.log("changePage",value)
  console.log("changePage",page)
 if(page == 'prev'){
  this.showData(Number(value)-1)
  const currentPage = this.imagesData.findIndex((obj:any) => obj.id === this.text_id);
  this.currentPage = currentPage - 1;
   console.log("currentPage",currentPage -1)
   this.router.navigate([`/review/${value}`])
 }else{
  this.showData(Number(value)+1)
  const currentPage = this.imagesData.findIndex((obj:any) => obj.id === this.text_id);
    this.currentPage = currentPage + 1;
   console.log("currentPage",currentPage +1)
   this.router.navigate([`/review/${value}`])
 }
 this.json_data_text(value)
}


loadDummyData(): void {
  const statuses = ['Finished', 'In Progress', 'New'];

  this.nerService.getImageData().subscribe((data:any)=>{
    console.log(data);
    this.imagesData = data
    this.lengthdata = data.length

  })
  
}

completJson(){

  var data = {
    "file_name":this.file_name ,
    "json_text_1": JSON.stringify(this.jsonFormat),
    "json_text_2":JSON.stringify(this.formattedOutput),
    "folder_name":  this.folder_name,
    "file_id":this.text_id
  }
  this.nerService.completJsonData(data).subscribe((data:any)=>{
    if(data){
      alert("Data saved successfully")
      this.router.navigate([`/review/${this.text_id}`])
    }
  })
}


json_data_text(id:any){
  
    this.nerService.json_data_str(id).subscribe((data:any)=>{
      console.log("data",data);
      if(data.length != 0){
        this.completeButton = true
        this.jsonFormat = JSON.parse(data[0].json_text_1)
        this.formattedOutput = JSON.parse(data[0].json_text_2)
        this.keyValue = this.formattedOutput
        console.log("keyvalue",this.jsonFormat.spans)
        this.labeleObjectvalue = this.jsonFormat.spans
      }else{
        this.completeButton = false
        this.jsonFormat = []  
        this.formattedOutput = []
        this.keyValue = []
        this.labeleObjectvalue = []

      }
      
    })
}

}

