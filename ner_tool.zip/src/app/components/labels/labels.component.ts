import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { NERService } from '../../shared/ner.service';

@Component({
  selector: 'app-labels',
  templateUrl: './labels.component.html',
  styleUrl: './labels.component.scss',
  standalone:false  
})
export class LabelsComponent implements OnInit {




  isModalOpen = false;
  labeldata:any
  labelForm!: FormGroup;

 // Display properties
 totalItems = 0;
 displayedItems: any= [];
 editMode = false;
 searchTerm = '';
 selectAll = false;
 
 // Pagination
 currentPage = 1;
 totalPages = 1;
 itemsPerPage = 10;
 pages: number[] = [];
 
 // Form properties
 currentItem: any = { name: '', color: '#73D8FF', shortkey: '' };
 isNameFocused = false;
 isKeyDropdownOpen = false;
 
 // Keys for dropdown
 numberKeys: string[] = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
 letterKeys: string[] = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 
                         'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
 
 // Color options
 colorOptions: string[] = [
   '#73D8FF', '#1E88E5', '#1E3A8A', '#9D65C9', '#6D28D9', '#4C1D95', '#F471B5',
   '#E91E63', '#9C27B0', '#4DD0E1', '#009688', '#00695C', '#CDDC39', '#8BC34A',
   '#0F482F', '#FFD600', '#FF9800', '#FF5722', '#F44336', '#B71C1C', '#7F0000'
 ];
 
 // Sample data
 allItems: any = [
   { id: 1, name: 'Florence Shaw', color: '#675578', shortkey: '1', selected: false },
   { id: 2, name: 'Quality Control', color: '#73D8FF', shortkey: '2', selected: false },
   { id: 3, name: 'Urgent', color: '#F44336', shortkey: 'U', selected: false },
 ];



  constructor(private fb:FormBuilder, private nerService:NERService) { 
    this.labelForm = this.fb.group({
      label: [''],
      color:['']
    });
  }

  openModal() {
    this.isModalOpen = true;
  }

  closeModal() {
    this.isModalOpen = false;
  }

  onSubmit() {  
    console.log(this.labelForm.value);
    this.nerService.addLabel(this.labelForm.value).subscribe((data:any)=>{
        console.log(data);
    })
    this.isModalOpen = false;
    alert('Label added successfully');
    this.getLabels()
  }
  ngOnInit(): void {
        this.getLabels()
        this.isModalOpen = false
  }

  selectColor(color: string) {
    const colorInput = document.getElementById('color-input') as HTMLInputElement;
    const colorPreview = document.getElementById('selected-color-preview') as HTMLDivElement;
    const labelPreview = document.getElementById('label-preview') as HTMLDivElement;
    const colorOptions = document.querySelectorAll('.color-option');

    if (colorInput && colorPreview && labelPreview) {
        colorInput.value = color;
        colorPreview.style.backgroundColor = color;
        labelPreview.style.backgroundColor = color;
    }

    colorOptions.forEach(option => {
        option.classList.remove('selected');
        if (option.getAttribute('data-color') === color) {
            option.classList.add('selected');
        }
    });
    this.labelForm.patchValue({color:color});
  }

  updateLabelPreview() {
    const labelInput = document.getElementById('label-name') as HTMLInputElement;
    const labelPreview = document.getElementById('label-preview') as HTMLDivElement;

    if (labelInput && labelPreview) {
        labelPreview.textContent = labelInput.value;
    }
  }

  getLabels(){
      this.nerService.getLabel().subscribe((data:any)=>{
          console.log(data);
          this.labeldata = data
      }
      )
  }


  changePage(page: number): void {
    if (page < 1 || page > this.totalPages) {
      return;
    }
    this.currentPage = page;
    // this.loadItems();
  }
  deleteItem(item: any): void {
    if (confirm(`Are you sure you want to delete "${item.name}"?`)) {
      this.allItems = this.allItems.filter((i:any) => i.id !== item.id);
      this.totalItems = this.allItems.length;
      // this.calculateTotalPages();
      // this.updatePages();
      // this.loadItems();
    }
  }
     // Open modal for adding new item
     openAddModal(): void {
      this.editMode = false;
      this.currentItem = { name: '', color: '#73D8FF', shortkey: '' };
      this.isModalOpen = true;
    }

       // Handle search input
   onSearchInput(event: Event): void {
    this.searchTerm = (event.target as HTMLInputElement).value;
    this.currentPage = 1;
    // this.loadItems();
  }
    // Reset color to default
    resetColor(): void {
      this.currentItem.color = '#73D8FF';
    }
     // Select key from dropdown
   selectKey(key: string): void {
    this.currentItem.shortkey = key;
    this.isKeyDropdownOpen = false;
  }
   // Toggle key dropdown
   toggleKeyDropdown(): void {
    this.isKeyDropdownOpen = !this.isKeyDropdownOpen;
  }
    
  
}
