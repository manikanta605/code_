import { Component, inject } from '@angular/core';
import { AddUserModalComponent } from './add-user-modal/add-user-modal.component';
import {MatDialog, MatDialogModule} from '@angular/material/dialog';
@Component({
    selector: 'app-user-management',
    templateUrl: './user-management.component.html',
    styleUrls: ['./user-management.component.scss'],
    standalone: false
})
export class UserManagementComponent {
  readonly dialog = inject(MatDialog);
  users = [
    { id: 1, name: 'John Doe', email: 'john@example.com', role: 'Admin' },
    { id: 2, name: 'Jane Smith', email: 'jane@example.com', role: 'User' }
  ];

  displayedColumns: string[] = ['id', 'name', 'email', 'role', 'actions'];
  openDialog() {
    const dialogRef = this.dialog.open(AddUserModalComponent,{
      height: '400px',
      width: '600px',
    });
    
    dialogRef.afterClosed().subscribe(result => {
      
      console.log(`Dialog result: ${result}`);
    });
  }
}