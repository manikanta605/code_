import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { UserManagementComponent } from './components/user-management/user-management.component';
import { SettingsComponent } from './components/settings/settings.component';
import { UserProfileComponent } from './components/user-profile/user-profile.component';
import { LoginComponent } from './auth/login/login.component';
import { SignupComponent } from './auth/signup/signup.component';
import { AuthGuard } from './auth/auth.guard';
import { ReviewComponent } from './components/review/review.component';
import { DatasetComponent } from './components/dataset/dataset.component';
import { LabelsComponent } from './components/labels/labels.component';
import { LabelActionComponent } from './label-action/label-action.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: '', redirectTo: '/login', pathMatch: 'full',},
  { path: 'dashboard', component: DashboardComponent,},
  { path: 'users', component: UserManagementComponent,},
  { path: 'settings', component: SettingsComponent,},
  { path: 'dataset', component: DatasetComponent,},
  { path: 'labels', component: LabelsComponent,},
  { path: 'profile', component: UserProfileComponent,},
  { path: 'review', component: ReviewComponent,},
  { path: 'review/:id', component: ReviewComponent,},
  { path: 'label_test', component: LabelActionComponent,}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }