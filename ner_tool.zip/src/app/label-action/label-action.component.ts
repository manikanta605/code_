import { Component, Input, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';

@Component({
  selector: 'app-label-action',
  templateUrl: './label-action.component.html',
  styleUrls: ['./label-action.component.css'],
  standalone: false
})
export class LabelActionComponent {
  @Input() label!: string;
  @Output() action = new EventEmitter<void>();
  labelToAdd: string = '';
  @ViewChild('selectedText') selectedText!: ElementRef;
  batchCounts: { [key: string]: number } = {};
  labeleObjectvalue:any = [];
  onAction() {
    this.action.emit();
  }

  addLabel(textArea: HTMLTextAreaElement) {
    const start = textArea.selectionStart;
    const end = textArea.selectionEnd;
    if (start !== end) {
      const selectedText = textArea.value.substring(start, end);
      const labeledText = `<${this.labelToAdd}>${selectedText}</${this.labelToAdd}>`;
      textArea.value = textArea.value.substring(0, start) + labeledText + textArea.value.substring(end);
    }
  }

  storeSelectedText(event: MouseEvent) {
    const textarea = event.target as HTMLTextAreaElement;
    const selectedText = textarea.value.substring(textarea.selectionStart, textarea.selectionEnd);
    this.selectedText.nativeElement.value = selectedText;
  }

  addPredefinedLabel(label: string, selectedText: string) {
    const labeledObject = {
      label: label,
      text: selectedText
    };
    this.labeleObjectvalue.push(labeledObject)
    console.log(labeledObject);
    // Increment the batch count for the label
    if (!this.batchCounts[label]) {
      this.batchCounts[label] = 0;
    }
    this.batchCounts[label]++;
    // ...existing code to handle the labeled object...
  }
}
