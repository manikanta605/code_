import os
import shutil
import logging

from fastapi import HTTPException
from paddleocr import PaddleOCR
from db import get_db_connection

logging.basicConfig(level=logging.INFO)

ocr = PaddleOCR(use_angle_cls=True, lang='en', use_space_char=True, show_log=False, enable_mkldnn=False)
# pipe = pipeline("text-generation", model="./zephyr-7b-alpha", torch_dtype=torch.bfloat16, device_map="auto")


def imageToText():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Retrieve records from the database
    query = "SELECT * FROM image_classification_1"
    cursor.execute(query)
    records = cursor.fetchall()
    
    # Extract column names for the records to convert to a dictionary format
    colnames = [desc[0] for desc in cursor.description]
    result = [dict(zip(colnames, record)) for record in records]
    
    # Filter for records with 'top_label' as 'DischargeSummary'
    discharge_summary_images = [record for record in result]
    
    skipped_records = []
    
    if discharge_summary_images:
        for row in discharge_summary_images:
            try:
                full_image_path = row['blob_image']
                if full_image_path and row['file_name'] and row['image'] and row['folder_name']:
                    Image_to_JSON(full_image_path, row['file_name'], row['image'], row['folder_name'])
                else:
                    raise ValueError("One or more required fields are None")
            except Exception as e:
                skipped_records.append({"record": row, "error": str(e)})
        
        # Log skipped records
        if skipped_records:
            log_file_path = "skipped_records.log"
            with open(log_file_path, 'w') as log_file:
                for skipped_record in skipped_records:
                    log_file.write(f"Skipped record: {skipped_record['record']} due to error: {skipped_record['error']}\n")
            logging.info(f"Skipped records logged in {log_file_path}")
        
        return {
            "message": "Summary images processed successfully.",
        }
    else:
        # Raise an error if no discharge summary images are found
        raise HTTPException(status_code=404, detail="No text Summary images found.")
    


def Image_to_JSON(image_path, subfolder, image_name, folder_name):
    print("image_path", image_path, subfolder, image_name)
    result = ocr.ocr(image_path, cls=True)
    ocr_string = " ".join([result[0][i][1][0] for i in range(len(result[0]))])
    # print("image_path", ocr_string)
    output_folder = "text_summary_output"
    insert_text_row(image_name,ocr_string,folder_name)
    # Ensure the output folder exists
    print("output folder", output_folder)
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # Ensure the folder_name directory exists within the output folder
    folder_path = os.path.join(output_folder, folder_name)
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

    txt_filename = f"{folder_name}/{subfolder}_{image_name}.txt"
    
    txt_path = os.path.join(output_folder, txt_filename)
    print("txt_filename", txt_path)
    with open(txt_path, 'w') as file:
        print(file, '--------')
        file.write(ocr_string)
        print(f"Saved {txt_filename} to {output_folder}")

    print(txt_path, '+++++++++++-------->>>>')
    return txt_path



def insert_excel_row(file_name, sheet,column_headings, text,folder_name):
    logging.info('Inserting into str_data_excel: %s, %s, %s, %s, %s', file_name, sheet, column_headings, text, folder_name)
    conn = get_db_connection()
    cursor = conn.cursor()
    # base64_string = image_to_base64(image_path)
    try:
        print('insert_image_classification',file_name, sheet, column_headings, text,folder_name)
        cursor.execute(
            "INSERT INTO str_data_excel (file_name, sheet_name, column_headings, text, folder_name) VALUES (%s, %s, %s,%s, %s)",
            (file_name, sheet, column_headings, text,folder_name)
        )
        conn.commit()
        logging.info('Insert successful')
    except Exception as e:
        conn.rollback()
        logging.error('Error inserting data: %s', str(e))
        raise HTTPException(status_code=500, detail=f"Error inserting image classification data: {str(e)}")
    finally:
        cursor.close()
        conn.close()
        
        
        
def insert_text_row(file_name, text,folder_name):
    logging.info('Inserting into str_data_excel: %s, %s, %s', file_name, text, folder_name)
    conn = get_db_connection()
    cursor = conn.cursor()
    # base64_string = image_to_base64(image_path)
    try:
        print('insert_image_classification',file_name,  text,folder_name)
        cursor.execute(
            "INSERT INTO image_data_text (file_name, text, folder_name) VALUES (%s, %s, %s)",
            (file_name, text, folder_name)
        )
        conn.commit()
        logging.info('Insert successful')
    except Exception as e:
        conn.rollback()
        logging.error('Error inserting data: %s', str(e))
        raise HTTPException(status_code=500, detail=f"Error inserting image classification data: {str(e)}")
    finally:
        cursor.close()
        conn.close()