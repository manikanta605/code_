# ------------------- Convert PDFs to Images -------------------

import os
from fastapi import HTTPException
from pdf2image import convert_from_path

from db import get_db_connection





def process_pdfs(root_input, root_output, overwrite=True):
    results = []
    dirpath_full = []
    total_pdfs = sum([len([f for f in files if f.lower().endswith('.pdf')]) for r, d, files in os.walk(root_input)])
    print(total_pdfs,"---------------------------")
    if total_pdfs == 0:
        raise HTTPException(status_code=400, detail="No PDFs found in the input folder.")

    error_log_path = os.path.join(root_output, "error_log.txt")
    with open(error_log_path, "w") as error_log:
        for dirpath, dirnames, filenames in os.walk(root_input):
            dirpath_full.append(dirnames)
            rel_path = os.path.relpath(dirpath, root_input)
            output_path = os.path.join(root_output, rel_path)
            os.makedirs(output_path, exist_ok=True)

            pdf_files = [f for f in filenames if f.lower().endswith('.pdf')]
            num_pdfs = len(pdf_files)
            num_images = 0
            status = "Process"

            for pdf_file in pdf_files:
                pdf_path = os.path.join(dirpath, pdf_file)
                pdf_filename = os.path.splitext(pdf_file)[0]
                print(pdf_filename,'pdf_filename')
                try:
                    images = convert_from_path(pdf_path)
                    num_images += len(images)
                    for i, image in enumerate(images, start=1):
                        image_filename = f"{pdf_filename}_{i}.png"
                        image_path = os.path.join(output_path, image_filename)
                        result_1 = "/".join(filter(None, [item[0] if item else '' for item in dirpath_full]))

                        print("result_1",result_1)
                        try:
                            insert_image_classification(pdf_filename, image_filename, image_path,result_1)
                        except Exception as e:
                            error_log.write(f"Error inserting image classification for {image_filename}: {e}\n")
                            print(f"Error inserting image classification for {image_filename}: {e}")
                        if not overwrite and os.path.exists(image_path):
                            continue
                        image.save(image_path, "PNG")
                except Exception as e:
                    error_log.write(f"Error processing {pdf_file}: {e}\n")
                    print(f"Error processing {pdf_file}: {e}")
                    status = "Error"
                    continue  # Skip to the next PDF file

                try:
                    insert_pdf_conversion(result_1, result_1, pdf_filename, '.pdf', len(images), status)
                except Exception as e:
                    error_log.write(f"Error inserting PDF conversion for {pdf_filename}: {e}\n")
                    print(f"Error inserting PDF conversion for {pdf_filename}: {e}")

            results.append({
                "Claim_id": os.path.basename(dirpath),  # Renamed Subfolder to Claim_id
                "Number of PDFs": num_pdfs,
                "Number of Images": num_images,
                "Status": status,
            })
    
    return results



# Function to insert PDF conversion results into the database
def insert_pdf_conversion(file_path, folder_name,file_name, file_extension,num_images, status):
    conn = get_db_connection()
    cursor = conn.cursor()
    # INSERT INTO public.pdf_conversion_1(
	# id, file_path, folder_name, file_name, file_extension, num_pages, status, created_at)
	# VALUES (?, ?, ?, ?, ?, ?, ?, ?);
    try:
        cursor.execute(
            "INSERT INTO pdf_conversion_1 (file_path, folder_name, file_name, file_extension, num_pages, status) VALUES (%s, %s, %s, %s,%s, %s)",
            (file_path,folder_name,file_name, file_extension, int(num_images), status)
        )
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=f"Error inserting PDF conversion data: {str(e)}")
    finally:
        cursor.close()
        conn.close()
        
def insert_image_classification(file_name, image, image_path,folder_name):
    # print('insert_image_classification',file_name, image, image_path)
    conn = get_db_connection()
    cursor = conn.cursor()
    # base64_string = image_to_base64(image_path)
    base64_string = image_path
    try:
        # print('insert_image_classification',file_name, image, image_path)
        cursor.execute(
            "INSERT INTO image_classification_1 (file_name, image, blob_image,folder_name) VALUES (%s, %s, %s,%s)",
            (file_name, image, base64_string,folder_name)
        )
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=f"Error inserting image classification data: {str(e)}")
    finally:
        cursor.close()
        conn.close()
