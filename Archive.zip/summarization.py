import os
import shutil
import logging

from fastapi import HTTPException
# from paddleocr import PaddleOCR
# from sklearn import pipeline

from transformers import LayoutLMv2ForSequenceClassification, LayoutLMv2Processor, pipeline
import torch



# logging.basicConfig(level=logging.INFO)

# ocr = PaddleOCR(use_angle_cls=True, lang='en', use_space_char=True, show_log=False, enable_mkldnn=False)
pipe = pipeline("text-generation", model="./zephyr-7b-alpha", torch_dtype=torch.bfloat16, device_map="auto")


ocr_string = " ".join(["TATA TECHNOLOGIES SCHEDULE - A Opportunity No : OP-124712 Opportunity Name : Dassault ALC Renewals 2010 Company :  TURBINE ENGINE COMPONENTS WIP : WIP 7 Currency : US Dollar TECH Shipping Address : Billing Address : Sales Rep : 1211 OLD ALBANY, Jennifer Swiderski THOMASVILLE, 31792 Tel. : Email: Key Contact : Ken Salacienski ksalacienski@tectcorp.com (216) 692-5200 Ps Primary : Bill Philip Ps Secondary : Total Forecast Amount : 12510.00 Forecasted Cost: 10248.00 Forecasted GP: 2262.00 Schedule A Details Cust PO No. PO received Taxable Tax Applicable Payment Charge For Autodesk Lic. Hardware Date (APAC) Terms Shipping Type S/N CLE19165 06-07-2010 Yes 30 No S/N for old Software : Hardware Model No : Approved : Comments to Finance : Sp. Shipping Instruction : Reason for Rejection: Please send PO to: dsac.billing@3ds.com Product Details Product Name Manu Part No Qty Price  Disc. Ext. Org. Overid GP S/N Unit Amount Cost e Cost Finance Mechanical Design 2 MD2 6 2085.00 12510.00 9408.00 10248.0 2262.00 Configuration o Dassault ALC Renewal 2010"])

messages = [
        {
            "role": "system",
            "content": "You are a JSON converter which receives raw  OCR information as a string and returns a structured JSON output by organizing the information in the string.",
        },
        {
            "role": "user",
            "content": f"Extract the following fields: Name,Person from this OCR data: {ocr_string}",
        },
    ]

prompt = pipe.tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
outputs = pipe(prompt, max_new_tokens=2500, do_sample=True, temperature=0.2, top_k=50, top_p=0.95)
generated_text = outputs[0]["generated_text"]
# output_folder = (
# "diagnostic_report_summary_output" if classification == "DiagnosticReports" else
# "kyc_report_output" if classification == "KycReports" else
# "cheque_report_output" if classification == "ChequeReports" else
# "billing_report_output" if classification == "HospitalBill" else
# "medical_report_output" if classification == "MedicalBills" else
# "discharge_summary_output"
# )
# # output_folder = "diagnostic_report_summary_output" if classification == "DiagnosticReports" else "kyc_report_output"  if classification == "KycReports" else "cheque_report_output"  if classification == "ChequeReports"   else "discharge_summary_output"
# print("output folder", output_folder)
# if not os.path.exists(output_folder):
#     os.makedirs(output_folder)

# txt_filename = f"{subfolder}/{subfolder}_{image_name}.txt"
# txt_path = os.path.join(output_folder, txt_filename)

# with open(txt_path, 'w') as file:
#     # print(file,'--------')
#     file.write(generated_text)
#     print(f"Saved {txt_filename} to {output_folder}")

print(generated_text,'+++++++++++-------->>>>')
