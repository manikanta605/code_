from fastapi import HTTPException
import psycopg2
from psycopg2 import sql
from psycopg2.extras import execute_values


# Function to create a connection to PostgreSQL
def get_db_connection():
    try:
        conn = psycopg2.connect(
            host="localhost",
            port="5433",
            database="merline_v4_db",
            user="postgres",
            password="12345"
        )
        return conn
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database connection failed: {str(e)}")
    