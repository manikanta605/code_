import os
from fastapi import File, UploadFile
import pandas as pd
from io import BytesIO
import openpyxl
import psycopg2
from pydantic import BaseModel
from db import get_db_connection
from datetime import datetime


class FolderPathRequest(BaseModel):
    root_input: str
    
    
def convert_to_string(value):
 
    return str(value)

def exceltotext(request: FolderPathRequest):
    try:
        print("request", request)
        conn = get_db_connection()
        cursor = conn.cursor()
        root_input = request.root_input
        folder_name = os.path.basename(root_input)
        output_dir = os.path.join(root_input, 'output_excel_txt')
        os.makedirs(output_dir, exist_ok=True)

        for root, _, files in os.walk(root_input):
            for file_name in files:
                if file_name.endswith(('.xls', '.xlsx')):
                    print(file_name, 'file_name')
                    file_path = os.path.join(root, file_name)
                    try:
                        with open(file_path, 'rb') as f:
                            contents = f.read()
                        excel_data = pd.ExcelFile(BytesIO(contents))
                    except Exception as e:
                        print(f"Skipping file {file_name} due to error: {str(e)}")
                        continue

                    for sheet_name in excel_data.sheet_names:
                        df = pd.read_excel(excel_data, sheet_name=sheet_name)
                        
                        # Add headers as a separate record
                        headers = ','.join(df.columns)
                        print("headers", sheet_name, headers)
                        
                        # Create a text file for each sheet
                        txt_file_path = os.path.join(output_dir, f"{os.path.splitext(file_name)[0]}_{sheet_name}.txt")
                        with open(txt_file_path, 'w') as txt_file:
                            txt_file.write(headers + '\n')
                        
                            for row_id, row in df.iterrows():
                                try:
                                    concatenated_columns = ','.join(map(convert_to_string, row.values))
                                    print("concatenated_columns", concatenated_columns)
                                    txt_file.write(concatenated_columns + '\n')
                                    
                                    # Insert into the database
                                    cursor.execute("""
                                        INSERT INTO public.str_data_excel(
                                            file_name, sheet_name, column_headings, row_id, text, folder_name, created_at)
                                        VALUES (%s, %s, %s, %s, %s, %s, %s);
                                    """, (file_name, sheet_name, headers, row_id, concatenated_columns, folder_name, datetime.now().isoformat()))
                                except Exception as e:
                                    print(f"Error processing row {row_id} in sheet {sheet_name} of file {file_name}: {str(e)}")
                                    continue

        # Commit the transaction and close the connection
        conn.commit()
        cursor.close()
        conn.close()

        return {"message": "Excel files processed and data inserted successfully"}

    except Exception as e:
        if conn:
            conn.rollback()
        if cursor:
            cursor.close()
        if conn:
            conn.close()
        raise Exception(f"An error occurred during the process in exceltotext function: {str(e)}")


async def upload_excel(file: UploadFile = File(...)):
    contents = await file.read()
    excel_data = pd.ExcelFile(BytesIO(contents))

    for sheet_name in excel_data.sheet_names:
        df = pd.read_excel(excel_data, sheet_name=sheet_name)
        
        # Add headers as a separate record
        headers = ','.join(df.columns)
        print("headers", sheet_name, headers)
        
        for _, row in df.iterrows():
            concatenated_columns = ','.join(map(str, row.values))
            print("concatenated_columns", sheet_name,headers, concatenated_columns)

    return {"message": "Excel file processed successfully"}